package com.dewcis.mdss.constants;

/**
 * Created by Khalif on 7/11/2017.
 */
public class Constant {
    public static final String KEY_ID = "_id",
            KEY_VALUE = "value";
    public static final String DRAFT_MOTHER = "draft_mother";
    public static final String DRAFT_BABY = "draft_baby";
    public static final String IS_DRAFT = "is_draft";
    public static final String DRAFT_KEY = "draft_key";
    public static final String ACTIVITY = "activity";
    public static String KEY_RAND = "client_rand";
    public static String KEY_ACTIVITY = "client_activity";
}
