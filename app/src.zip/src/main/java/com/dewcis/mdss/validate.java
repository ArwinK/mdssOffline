package com.dewcis.mdss;


import android.support.v7.app.AlertDialog;
import android.widget.Toast;

import com.google.android.gms.appinvite.AppInviteInvitation;
import com.rengwuxian.materialedittext.MaterialEditText;

import cn.pedant.SweetAlert.SweetAlertDialog;

public class validate {

    public void babyWeight(MaterialEditText materialEditText){
        if (Integer.parseInt(materialEditText.getText().toString())>8){
            //SweetAlertDialog sweetAlertDialog = new SweetAlertDialog(this, SweetAlertDialog.WARNING_TYPE);
        }
    }
    public void babyAge(MaterialEditText materialEditText){
        if (Integer.parseInt(materialEditText.getText().toString())>24){
            //SweetAlertDialog sweetAlertDialog = new SweetAlertDialog(this, SweetAlertDialog.WARNING_TYPE);
        }
    }
    public void focus(MaterialEditText materialEditText){
        materialEditText.setFocusable(false);
    }
}
