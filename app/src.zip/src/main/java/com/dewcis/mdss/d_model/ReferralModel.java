package com.dewcis.mdss.d_model;

/**
 * Created by Khalif on 7/14/2017.
 */
public class ReferralModel {

}
