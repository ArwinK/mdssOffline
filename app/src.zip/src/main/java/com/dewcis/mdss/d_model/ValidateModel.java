package com.dewcis.mdss.d_model;

/**
 * Created by Khalif on 7/17/2017.
 */
public class ValidateModel {
    public String message = "";
    public boolean state = true;
}