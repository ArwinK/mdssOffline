package com.dewcis.mdss.adapters;

/**
 * Created by Arwin Kish on 5/15/2017.
 */
public class DraftAdapter {
}
